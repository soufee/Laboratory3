CREATE FUNCTION st_covers (geography, geography) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($1, $2)
$$

CREATE FUNCTION st_setvalue (rast raster, x integer, y integer, newvalue double precision) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT public.ST_setvalue($1, 1, $2, $3, $4) 
$$

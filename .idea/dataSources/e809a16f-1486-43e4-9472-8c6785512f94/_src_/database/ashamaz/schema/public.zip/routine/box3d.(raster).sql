CREATE FUNCTION box3d (raster) RETURNS box3d
	LANGUAGE sql
AS $$
select box3d( public.ST_convexhull($1))
$$

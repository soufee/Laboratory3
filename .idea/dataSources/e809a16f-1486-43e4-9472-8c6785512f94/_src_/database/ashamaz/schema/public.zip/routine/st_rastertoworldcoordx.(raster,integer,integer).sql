CREATE FUNCTION st_rastertoworldcoordx (rast raster, xr integer, yr integer) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT longitude FROM public._ST_rastertoworldcoord($1, $2, $3) 
$$

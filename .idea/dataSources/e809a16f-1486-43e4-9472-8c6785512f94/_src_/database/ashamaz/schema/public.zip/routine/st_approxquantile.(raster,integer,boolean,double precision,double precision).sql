CREATE FUNCTION st_approxquantile (rast raster, nband integer, exclude_nodata_value boolean, sample_percent double precision, quantile double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ( public._ST_quantile($1, $2, $3, $4, ARRAY[$5]::double precision[])).value 
$$

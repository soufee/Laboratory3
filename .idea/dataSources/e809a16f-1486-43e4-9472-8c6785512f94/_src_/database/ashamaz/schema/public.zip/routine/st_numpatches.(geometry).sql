CREATE FUNCTION st_numpatches (geometry) RETURNS integer
	LANGUAGE sql
AS $$
	SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_NumGeometries($1)
	ELSE NULL END
	
$$

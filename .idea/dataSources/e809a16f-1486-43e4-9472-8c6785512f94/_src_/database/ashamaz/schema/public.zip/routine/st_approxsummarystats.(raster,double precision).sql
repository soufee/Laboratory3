CREATE FUNCTION st_approxsummarystats (rast raster, sample_percent double precision) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT public._ST_summarystats($1, 1, TRUE, $2) 
$$

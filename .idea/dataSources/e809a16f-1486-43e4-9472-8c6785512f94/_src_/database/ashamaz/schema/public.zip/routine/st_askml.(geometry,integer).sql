CREATE FUNCTION st_askml (geom geometry, maxdecimaldigits integer DEFAULT 15) RETURNS text
	LANGUAGE sql
AS $$
 SELECT public._ST_AsKML(2, ST_Transform($1,4326), $2, null); 
$$

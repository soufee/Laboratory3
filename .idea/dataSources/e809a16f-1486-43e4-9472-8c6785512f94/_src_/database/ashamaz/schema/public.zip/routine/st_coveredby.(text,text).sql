CREATE FUNCTION st_coveredby (text, text) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT ST_CoveredBy($1::public.geometry, $2::public.geometry);  
$$

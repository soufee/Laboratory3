CREATE FUNCTION st_crosses (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Crosses($1,$2)
$$

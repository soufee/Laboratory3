CREATE FUNCTION st_asjpeg (rast raster, nband integer, options text[] DEFAULT NULL::text[]) RETURNS bytea
	LANGUAGE sql
AS $$
 SELECT st_asjpeg(st_band($1, $2), $3) 
$$

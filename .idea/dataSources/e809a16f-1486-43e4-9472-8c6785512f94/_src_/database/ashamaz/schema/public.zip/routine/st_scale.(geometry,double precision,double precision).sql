CREATE FUNCTION st_scale (geometry, double precision, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_Scale($1, $2, $3, 1)
$$

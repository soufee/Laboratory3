CREATE FUNCTION st_line_substring (geometry, double precision, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT public._postgis_deprecate('ST_Line_Substring', 'ST_LineSubstring', '2.1.0');
     SELECT public.ST_LineSubstring($1, $2, $3);
  
$$

CREATE FUNCTION st_gmltosql (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public._ST_GeomFromGML($1, 0)
$$

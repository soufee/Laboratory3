CREATE FUNCTION st_quantile (rastertable text, rastercolumn text, nband integer, quantile double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ( public._ST_quantile($1, $2, $3, TRUE, 1, ARRAY[$4]::double precision[])).value 
$$
